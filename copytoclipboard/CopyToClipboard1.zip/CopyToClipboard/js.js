$(document).ready(function() {

    var clip = new ZeroClipboard($("#copy_button"), {
        moviePath: "ZeroClipboard.swf"
    });
});