<?php 
include($_SERVER['DOCUMENT_ROOT']."/classes/access_user/access_user_class.php"); 
$access_denied = new Access_user;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Access denied!</title>
<meta name="description" content="">
<meta name="keywords" content="">
</head>
<body>
<h2>Access denied!</h2>
<p>It's not allowed to your account to view this site!</p>
<p>&nbsp;</p>
<p><a href="<?php echo $access_denied->main_page; ?>">Main</a></p>
</body>
</html>