# File Upload with AJAX
User can upload the file with AJAX. Once the file will be selected by User, the Script will confirm user to upload file or not. If user allow to upload file, it will be uploaded to the server and return the File Name and Download Link of the uploaded file. 

# Developed By : 
Bharat Parmar

# Version : 
1.0

# File Structure :
1) example.php  : Example Script file 
2) ajax.class.php : This file will upload the selected file to the "upload" directory.
3) upload : This directory will store uploaded files.
4) jquery.min.js : JQuery File for the AJAX and Javascript functions.


# Requirements : 
1) PHP Version : 3.0 and above

