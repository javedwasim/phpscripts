<?php
require "config.php";
?>
<!DOCTYPE html>
<html>
	<head></head>
	<body>
 		<p>The Index Page</p>
 		<a href="login.php">Login</a>
	</body>
</html>
