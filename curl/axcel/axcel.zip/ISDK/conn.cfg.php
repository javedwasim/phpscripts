<?php

$connInfo = array('kq272:kq272:i:b85799b515301febee1c71232750a8ed:This is the connection for kq272.infusionsoft.com');
?>