<?php

$connInfo = array('ul232:ul232:i:f3d66d11ec68d723d9a6a3385b46ee28:This is infusionsoft');

?>